# 佳乐的博客（VitePress 版）

这是使用 VitePress 构建的个人博客项目。

## 🚀 快速启动（实时预览）

### 前置要求
- Node.js 18+ 已安装（推荐 20+）
- npm 或 pnpm

### 启动步骤

```bash
# 1. 进入项目目录
cd vitepress-blog

# 2. 安装依赖（首次需要）
npm install

# 3. 启动开发服务器（实时预览）
npm run docs:dev
```

启动成功后，浏览器会自动打开：

**http://localhost:5173**

现在你可以实时编辑 Markdown 文件，页面会自动热更新！

---

## 📁 项目结构

```
vitepress-blog/
├── docs/                      # 内容目录
│   ├── .vitepress/
│   │   └── config.mts         # 站点配置（导航、主题、侧边栏等）
│   ├── index.md               # 首页
│   ├── about.md               # 关于我
│   └── posts/                 # 文章目录
│       ├── welcome.md
│       ├── vitepress-guide.md
│       └── ai-assistant.md
├── package.json
└── README.md
```

---

## ✍️ 如何添加新文章

1. 在 `docs/posts/` 目录下新建 `.md` 文件
2. 文件开头添加 frontmatter：

```md
---
title: 文章标题
date: 2026-06-21
author: 佳乐
---

# 正文内容
```

3. 保存后，开发服务器会自动更新，侧边栏也会自动识别。

---

## 🛠 常用命令

| 命令                    | 说明                  |
|-------------------------|-----------------------|
| `npm run docs:dev`      | 启动开发服务器（推荐） |
| `npm run docs:build`    | 构建生产版本          |
| `npm run docs:preview`  | 预览生产构建结果      |

---

## 🌍 部署建议

推荐部署平台（免费且简单）：
- **Vercel**（最推荐）
- **Netlify**
- **GitHub Pages**

部署后即可获得真实在线地址。

---

**需要我帮你添加更多文章、修改主题、增加功能吗？**  
直接告诉我即可！