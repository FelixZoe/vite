---
layout: home

hero:
  name: "佳乐的博客"
  text: "技术 · 思考 · 生活"
  tagline: "用代码记录世界，用文字分享思考"
  actions:
    - theme: brand
      text: 开始阅读
      link: /posts/
    - theme: alt
      text: 关于我
      link: /about

features:
  - icon: 🚀
    title: 技术分享
    details: 前端、AI、工具链等实用技术文章
  - icon: 💡
    title: 深度思考
    details: 对产品、设计与人生的独立思考
  - icon: 🌱
    title: 持续成长
    details: 记录学习过程与成长足迹
---