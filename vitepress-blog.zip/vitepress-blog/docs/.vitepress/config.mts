import { defineConfig } from 'vitepress'

export default defineConfig({
  lang: 'zh-CN',
  title: '佳乐的博客',
  description: '分享技术、思考与生活',
  base: '/',
  cleanUrls: true,
  lastUpdated: true,

  head: [
    ['link', { rel: 'icon', href: '/favicon.ico' }]
  ],

  themeConfig: {
    logo: false,

    nav: [
      { text: '首页', link: '/' },
      { text: '所有文章', link: '/posts/' },
      { text: '关于我', link: '/about' }
    ],

    sidebar: [
      {
        text: '最新文章',
        collapsed: false,
        items: [
          { text: '欢迎来到我的博客', link: '/posts/welcome' },
          { text: '如何使用 VitePress 搭建博客', link: '/posts/vitepress-guide' },
          { text: 'AI 助手的使用心得', link: '/posts/ai-assistant' },
          { text: '在新加坡的生活与工作', link: '/posts/singapore-life' }
        ]
      },
      {
        text: '分类',
        collapsed: true,
        items: [
          { text: '技术与工具', link: '/posts/vitepress-guide' },
          { text: 'AI 与思考', link: '/posts/ai-assistant' },
          { text: '生活记录', link: '/posts/singapore-life' }
        ]
      }
    ],

    editLink: {
      pattern: 'https://github.com/edit/main/docs/:path',
      text: '在 GitHub 上编辑此页'
    },

    search: {
      provider: 'local'
    },

    socialLinks: [
      { icon: 'github', link: 'https://github.com' },
      { icon: 'twitter', link: 'https://twitter.com' }
    ],

    footer: {
      message: '用 ❤️ 和 VitePress 构建',
      copyright: '© 2026 佳乐 · 保留所有权利'
    },

    outline: {
      label: '本页目录',
      level: [2, 3]
    }
  }
})