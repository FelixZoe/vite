---
title: 如何使用 VitePress 搭建个人博客
date: 2026-06-20
author: 佳乐
---

# 如何使用 VitePress 搭建个人博客

VitePress 是基于 Vite 和 Vue 的静态站点生成器，非常适合做技术博客和文档站。

## 优点
- 极快的冷启动和热更新
- Markdown + Vue 组件支持
- 内置搜索、暗黑模式、响应式
- 配置简单，主题优雅

## 快速开始（本地运行）

```bash
# 1. 创建项目（需要 Node.js）
npm create vitepress@latest

# 2. 进入目录
cd your-blog

# 3. 安装依赖
npm install

# 4. 启动开发服务器
npm run docs:dev
```

## 本博客结构
```
vitepress-blog/
├── docs/
│   ├── .vitepress/
│   │   └── config.mts      # 配置文件
│   ├── index.md            # 首页
│   ├── about.md
│   └── posts/              # 文章目录
│       ├── welcome.md
│       └── ...
├── package.json
└── ...
```

## 部署
推荐使用 GitHub Pages、Vercel 或 Netlify，一键部署非常方便。

---

想自己搭建类似博客？可以直接下载本项目文件使用！